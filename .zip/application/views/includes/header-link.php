<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="template" content="Kisan Greens | Farm Fresh Product in Bhopal, Madhya Pradesh">
	<meta name="title" content="Kisan Greens | Farm Fresh Product in Bhopal, Madhya Pradesh">
	<meta name="keywords" content=" Kisan Greens derives its name from the significance of the  Greens that sustain life on Earth. Just like the Sun is essential for our planet, nothing is more vital to us than the green plants that provide food and oxygen, making life possible.">
	<title>Kisan Greens | Farm Fresh Product in Bhopal, Madhya Pradesh</title>
	<link rel="icon" href="<?= base_url() ?>assets/images/favicon.png">
	<link rel="stylesheet" href="<?= base_url() ?>assets/fonts/flaticon/flaticon.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/fonts/icofont/icofont.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/fonts/fontawesome/fontawesome.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/vendor/venobox/venobox.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/vendor/slickslider/slick.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/vendor/niceselect/nice-select.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/vendor/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/main.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/index.css">
	<link rel="stylesheet" href="<?= base_url() ?>assets/css/product-details.css">
</head>